package com.test.context;

import core.api.RestClient;
import core.ui.UiClient;
import lombok.Data;
import model.api.Order;
import model.api.Posts;
import model.ui.*;

@Data
public class TestContext {
    private RestClient restClient;
    private UiClient uiClient;

    public CurrencyConverter currencyConverter() {
        return new CurrencyConverter(this.getUiClient());
    }

    public SendMoney sendMoney(){
        return new SendMoney(this.getUiClient());
    }


    public Posts posts() {
        return new Posts(this.getRestClient());
    }

    public Order order() {
        return new Order(this.getRestClient());
    }

}


