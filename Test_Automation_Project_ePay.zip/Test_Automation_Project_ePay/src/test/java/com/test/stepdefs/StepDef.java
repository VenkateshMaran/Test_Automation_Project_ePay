package com.test.stepdefs;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.test.context.TestContext;
import com.test.context.TestEnvironment;
import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import model.api.Order;
import model.api.Posts;
import model.ui.CurrencyConverter;
import model.ui.SendMoney;
import org.assertj.core.api.Assertions;
import org.springframework.beans.factory.annotation.Autowired;

public class StepDef {

    @Autowired
    TestContext testContext;

    @Autowired
    TestEnvironment testEnvironment;

    Posts posts;
    Order order;

    SendMoney sendMoney;

    CurrencyConverter currencyConverter;




    @When("rest client request posts")
    public void restClientRequestPosts() {
        posts = testContext.posts().getPosts();
    }

    @Then("all title should not be empty")
    public void allTitleShouldNotBeEmpty() {
            Assertions.assertThat(posts.getAllTitle()).allMatch(title -> !title.isEmpty());
    }

    @And("all body should not be empty")
    public void allBodyShouldNotBeEmpty() {
        Assertions.assertThat(posts.getAllBody()).allMatch(body -> !body.isEmpty());
    }

    @And("response body fields should not contain zombie")
    public void checkZombie() {
        Assertions.assertThat(posts.isNotZombie()).isTrue();
    }

    @When("rest client post order")
    public void restClientPostOrder() throws JsonProcessingException {
        order = testContext.order().orderItem();
    }

    @Then("response status code should be {int}")
    public void responseStatusCodeShouldBe(int statusCode) {
        Assertions.assertThat(testContext.getRestClient().getLastResponse().statusCode()).isEqualTo(statusCode);
    }

    @And("response data contains below toppings")
    public void toppingContains(DataTable toppings) {
        Assertions.assertThat(order.getToppings()).isEqualTo(toppings.asList());

    }

    @And("toppings should not contains chicken")
    public void toppingContains() {
        Assertions.assertThat(order.isToppingContainsChicken()).isFalse();

    }

 @Given("user is on currency converter page")
    public void currencyConverterPage() {
testContext.currencyConverter().url();

    }

    @And("check validation for Amount by entering alphabets")
    public void amountValidation() {

        Assertions.assertThat(testContext.currencyConverter().amountValidation()).isEqualTo("Please enter a valid amount");

    }

    @And("check India available in From Country")
    public void countryAvailable() {

        Assertions.assertThat(testContext.currencyConverter().countryValidation()).isEqualTo("INR - Indian Rupee");
    }
    @And("check convert button is enabled")
    public void buttonEnabled() {

       Assertions.assertThat(testContext.currencyConverter().convertButtonAvailable().isEnabled());

    }

    @When("calculate conversion rate for {string} {string} to EUR")
    public void calculate(String amount, String currency) {
       String calVal =  testContext.currencyConverter().getCurrencyConversion(amount,currency);
        System.out.println(calVal);
    }
    @Then("validate the conversion result")
    public void validate(){
        Assertions.assertThat(testContext.currencyConverter().result());
    }
@Given("User Navigated to Send Money Page")
public void sendMoneyPage(){
    testContext.sendMoney().url();
}

    @When("click signin and send")
    public void clickSigninAndSend() {
        testContext.sendMoney().signInAndSend();
    }

    @And("enters username and password")
    public void entersUsernameAndPassword() {
        testContext.sendMoney().registrationForm(testEnvironment.getUi_username(),testEnvironment.getUi_password());
    }

    @Then("verify user registration is enabled")
    public void registrationIsEnabled() {

        Assertions.assertThat(testContext.sendMoney().registerNow().isEnabled());
    }
}

