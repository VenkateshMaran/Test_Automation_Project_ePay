package core.ui;


import lombok.SneakyThrows;


import org.asynchttpclient.util.Assertions;
import org.openqa.selenium.*;

import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.Select;

import java.util.List;
import java.util.concurrent.TimeUnit;



public class UiClient {

    private final String baseUrl;

    private final int DEFAULT_TIMEOUT_IN_SECONDS = 120;

    public UiClient(String baseUrl) {
        this.baseUrl = baseUrl;
    }

    public WebDriver driver;

    public WebElement inputElement;

    public void launch() {
        driver = new ChromeDriver(chromeOptions());
    }

    private ChromeOptions chromeOptions() {
        System.setProperty("webdriver.chrome.driver", "E:\\Java_Selenium\\chromedriver_win32\\chromedriver.exe");

        ChromeOptions chromeOptions = new ChromeOptions();
        chromeOptions.addArguments("--start-maximized");
        return chromeOptions;
    }

    @SneakyThrows
    public WebElement findElement(By by) {
        int i = 0;
        while (i < DEFAULT_TIMEOUT_IN_SECONDS) {
            try {
                return driver.findElement(by);
            } catch (Exception e) {
                System.out.println("Element not visible => " + by.toString());
                Thread.sleep(1000);
                i++;
            }
        }
        throw new RuntimeException("Element not found => " + by.toString());
    }

    public void loadBaseUrl() {
    driver.get(this.baseUrl);
    }

    public void loadUrl(String url) {
        driver.get(url);
    }
    public void refresh(){

        driver.navigate().refresh();

    }
    public String selectInputDropdownValue(String inputId, String optionValue) {

         inputElement = driver.findElement(By.xpath(inputId));
        inputElement.click();
        inputElement.sendKeys(optionValue);
        inputElement.sendKeys(Keys.DOWN);
        inputElement.sendKeys(Keys.ENTER);
        return inputElement.getAttribute("value");
    }

    public void close(){
        driver.close();
    }
    }














