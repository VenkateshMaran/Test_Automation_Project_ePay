package core.api;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

import java.util.HashMap;

import java.util.Map;

public class RestClient {

    private final String host;
    private final int port;
    private final Map<String, Object> headers = new HashMap<>();
    private Response response;

    public Response getLastResponse() {
        return this.response;
    }

    public RestClient(String host, int port) {
        this.host = host;
        this.port = port;
    }

    public Response get(String endPoint, Map<String, Object> params) {
        return this.response = requestSpecification().queryParams(params).get(endPoint)
                .then()
                .log()
                .all().extract().response();
    }

    public Response post(String endPoint, String requestBody) {
        return this.response = requestSpecification().body(requestBody).post(endPoint)
                .then()
                .log()
                .all().extract().response();
    }

    public void addHeader(String name, Object value) {
        this.headers.put(name, value);
    }

    public RequestSpecification requestSpecification() {
        return RestAssured.given().relaxedHTTPSValidation()
                .log().all(true)
                .baseUri(host)
                .port(port).headers(headers);
    }

}
