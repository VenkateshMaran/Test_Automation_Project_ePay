package model.ui;

import core.ui.UiClient;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;

public class CurrencyConverter {

    public UiClient uiClient;

    private String url="https://www.xe.com/currencyconverter/";
    public CurrencyConverter(UiClient uiClient) {
        this.uiClient= uiClient;

    }

    private final By amount = By.xpath("//input[@id='amount']");
    private final By from = By.xpath("//input[@id='midmarketFromCurrency']");

    private final By to = By.xpath("//input[@id='midmarketToCurrency']");
    private final By convert = By.cssSelector("div.fluid-container__BaseFluidContainer-qoidzu-0.gJBOzk:nth-child(3) section.large-container-sc-1j708v7-0.fsQASC div.tab-box__MainTabContainer-sc-28io75-0.eTaaZi main.tab-box__ContentContainer-sc-28io75-3.jFGFzo div:nth-child(1) div.currency-converter__SubmitZone-zieln1-3.eIzYlj > button.button__BaseButton-sc-1qpsalo-0.clGTKJ");
    private final By cookieaccept= By.xpath("//button[contains(text(),'Accept')]");

    private final By finalresult = By.cssSelector("div.fluid-container__BaseFluidContainer-qoidzu-0.gJBOzk:nth-child(3) section.large-container-sc-1j708v7-0.fsQASC div.tab-box__MainTabContainer-sc-28io75-0.eTaaZi main.tab-box__ContentContainer-sc-28io75-3.jFGFzo div:nth-child(1) div:nth-child(2) div:nth-child(1) > p.result__BigRate-sc-1bsijpp-1.iGrAod");

    private By validationelement = By.cssSelector("div.fluid-container__BaseFluidContainer-qoidzu-0.gJBOzk:nth-child(3) section.large-container-sc-1j708v7-0.fsQASC div.tab-box__MainTabContainer-sc-28io75-0.eTaaZi main.tab-box__ContentContainer-sc-28io75-3.jFGFzo div:nth-child(1) div.currency-converter__GridContainer-zieln1-1.jdUeRL > div.currency-converter__ErrorText-zieln1-2.dkXbBF:nth-child(3)");

    private String fromtxtbox = "//input[@id='midmarketFromCurrency']";

    private WebElement res;

    private String selectedOption;


    private WebElement fromCountrySelection;
    public void url(){
        uiClient.loadUrl(this.url);
    }
public String amountValidation(){
    uiClient.refresh();
    uiClient.findElement(this.cookieaccept).click();
    uiClient.findElement(this.amount).sendKeys("Abcdef");
    res = uiClient.findElement(this.validationelement);
    return res.getText();

  }

  public String countryValidation(){
      uiClient.refresh();
       uiClient.findElement(this.from).sendKeys("INR"+Keys.ENTER);
      selectedOption = uiClient.selectInputDropdownValue(this.fromtxtbox,"INR - Indian Rupee");
      return selectedOption;

  }

public WebElement convertButtonAvailable(){
   return uiClient.findElement(this.convert);
    }
public String result(){
    res = uiClient.findElement(this.finalresult);
    return res.getText();

}


    public String getCurrencyConversion(String amount, String currency){
        uiClient.findElement(this.amount).sendKeys(amount);
        fromCountrySelection =uiClient.findElement(this.from);
        fromCountrySelection.sendKeys(currency + Keys.ENTER);
        uiClient.findElement(this.convert).click();
        res = uiClient.findElement(this.finalresult);
        return res.getText();
    }
}
