package model.ui;

import core.ui.UiClient;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import java.util.Collections;
import java.util.Objects;

public class SendMoney {

    public UiClient uiClient;

 private String url ="https://www.xe.com/send-money/";
    public SendMoney(UiClient uiClient) {
        this.uiClient = uiClient;

    }

    private final By signinandsend = By.xpath("//a[contains(text(),'Sign in and send')]");
    private final By username = By.id("email");

    private final By password = By.id("password");
    private final By registernow = By.xpath("//button[contains(text(),'Register now')]");

    private final By cookieaccept= By.xpath("//button[contains(text(),'Accept')]");

    public void url(){
        uiClient.loadUrl(this.url);
    }
    public void signInAndSend() {

        uiClient.findElement(this.signinandsend).click();

        uiClient.findElement(this.cookieaccept).click();

    }

    public WebElement registerNow() {
       return  uiClient.findElement(this.registernow);

    }

    public void registrationForm(String un, String pass) {

        uiClient.refresh();

        uiClient.findElement(this.username).sendKeys(un);
        uiClient.findElement(this.password).sendKeys(pass);
    }



}
