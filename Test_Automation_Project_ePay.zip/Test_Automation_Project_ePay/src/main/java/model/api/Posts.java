package model.api;

import core.api.RestClient;

import java.util.Collections;
import java.util.List;
import java.util.Objects;

public class Posts {

    private final String END_POINT = "https://jsonplaceholder.typicode.com/posts/";
    private final RestClient restClient;

    public Posts(RestClient restClient) {
        this.restClient = restClient;
    }

    public Posts getPosts() {
        this.restClient.get(END_POINT, Collections.emptyMap());
        return this;
    }

    public List<String> getAllTitle() {
        return this.restClient.getLastResponse().jsonPath().getList("title");
    }

    public List<String> getAllBody() {
        return this.restClient.getLastResponse().jsonPath().getList("body");
    }
    public boolean isNotZombie() {
        return this.restClient.getLastResponse().jsonPath().getList("zombie").stream().noneMatch(Objects::nonNull);
    }


}
