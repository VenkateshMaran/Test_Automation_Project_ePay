package model.api;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.google.gson.Gson;
import core.api.RestClient;
import lombok.Builder;
import lombok.Data;

import java.util.List;

public class Order {

    private final String END_POINT = "https://httpbin.org/post";
    private final RestClient restClient;
    private final Gson gson = new Gson();
    public Order(RestClient restClient) {
        this.restClient = restClient;
    }

    public Order orderItem() throws JsonProcessingException {
        this.restClient.post(END_POINT, gson.toJson(Item.orderItem()));
        return this;
    }

    public boolean isToppingContainsChicken() {
        return getItemFromResponse().getTopping().contains("chicken");
    }

    public List<String> getToppings() {
        return getItemFromResponse().getTopping();
    }

    private Item getItemFromResponse() {
        return gson.fromJson(this.restClient.getLastResponse().jsonPath().getString("data"), Item.class);
    }

}

@Builder
@Data
class Item {

    private String student;
    private String email_address;

    private String phone;
    private String current_grade;
    private List<String> topping;

    public static Item orderItem(){
       return Item.builder().student("Tim Allen").email_address("tim@homeimprovement.com").phone("(408) 8674530")
               .current_grade("B+")
                .topping(List.of("bacon", "cheese", "mushroom")).build();
    }
}